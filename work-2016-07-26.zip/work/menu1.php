 <h3> Navigation:  >><a href="home.php">Home Page</a>>><a href="registration.php">Registrartion</a>>><a href="new_task.php">New Task</a>>><a href="search.php">Search</a>
 </h3>