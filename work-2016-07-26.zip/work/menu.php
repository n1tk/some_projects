
<div class="sidebar1">
  <nav>
    <ul>
      <li>MENU</li>
      
      <li><a href="home.php">Home page</a></li>
      <li><a href="registration.php">Registration</a></li>
      <li><a href="new_task.php">New task</a></li>
      <li><a href="search.php">Search</a></li>
    </ul>
</nav>
 </div>
